const express = require('express');
const router = express.Router();
const axios = require('axios');
const { protect } = require('../middleware/auth');
const Chat = require('../models/Chat');
const User = require('../models/User');

// =============================================
// GEMINI API INTEGRATION
// =============================================
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent';

const callGeminiAPI = async (messages) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error('Gemini API key not configured.');

  // System instruction for coding-focused AI
  const systemInstruction = `You are Infamous AI, a highly intelligent, coding-focused AI assistant. 
You are expert in all programming languages, frameworks, algorithms, databases, DevOps, and software engineering.
You provide:
- Clean, well-commented code with explanations
- Step-by-step debugging help
- Architecture & design pattern advice
- Real, accurate, working solutions
- Concise but thorough answers
Format code in proper markdown code blocks with language labels.
Be direct, technical, and accurate. Never give vague or placeholder responses.`;

  // Convert messages to Gemini format
  const contents = messages.map((msg) => ({
    role: msg.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: msg.content }],
  }));

  const response = await axios.post(
    `${GEMINI_API_URL}?key=${apiKey}`,
    {
      systemInstruction: { parts: [{ text: systemInstruction }] },
      contents,
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 8192,
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' },
      ],
    },
    { timeout: 60000 }
  );

  const candidate = response.data?.candidates?.[0];
  if (!candidate?.content?.parts?.[0]?.text) {
    throw new Error('No valid response from AI. Please try again.');
  }

  return candidate.content.parts[0].text;
};

// =============================================
// ROUTES
// =============================================

// @route   POST /api/chat/send
// @desc    Send message and get AI response
// @access  Private
router.post('/send', protect, async (req, res) => {
  try {
    const { message, chatId } = req.body;
    const user = req.user;

    if (!message || !message.trim()) {
      return res.status(400).json({ success: false, message: 'Message cannot be empty.' });
    }

    // Check and reset daily limit
    user.checkAndResetLimit();
    await user.save({ validateBeforeSave: false });

    // Check message limit
    if (!user.canSendMessage()) {
      return res.status(429).json({
        success: false,
        message: `Daily limit reached. Your ${user.plan.toUpperCase()} plan allows ${user.getMessageLimit()} messages/day. Upgrade your plan to continue.`,
        limitReached: true,
        plan: user.plan,
        limit: user.getMessageLimit(),
      });
    }

    let chat;

    // Load or create chat
    if (chatId) {
      chat = await Chat.findOne({ _id: chatId, user: user._id });
      if (!chat) {
        return res.status(404).json({ success: false, message: 'Chat not found.' });
      }
    } else {
      chat = new Chat({ user: user._id, title: 'New Chat', messages: [] });
    }

    // Add user message
    chat.messages.push({ role: 'user', content: message.trim() });

    // Build conversation history for API (last 20 messages for context)
    const historyMessages = chat.messages.slice(-20).map((m) => ({
      role: m.role,
      content: m.content,
    }));

    // Call Gemini API
    const aiResponse = await callGeminiAPI(historyMessages);

    // Add assistant response
    chat.messages.push({ role: 'assistant', content: aiResponse });

    // Auto-generate title from first message
    if (chat.messages.length === 2) {
      chat.generateTitle();
    }

    await chat.save();

    // Increment user message count
    user.messageCount += 1;
    await user.save({ validateBeforeSave: false });

    console.log(`[CHAT] User: ${user.username} | Plan: ${user.plan} | Usage: ${user.messageCount}/${user.getMessageLimit()} | Chat: ${chat._id}`);

    res.json({
      success: true,
      chatId: chat._id,
      response: aiResponse,
      messageCount: user.messageCount,
      remaining: user.getRemainingMessages(),
      limit: user.getMessageLimit(),
      title: chat.title,
    });
  } catch (err) {
    console.error('[CHAT SEND ERROR]', err.message);

    if (err.response?.status === 429) {
      return res.status(429).json({ success: false, message: 'AI API rate limit reached. Please wait a moment.' });
    }
    if (err.response?.status === 400) {
      return res.status(400).json({ success: false, message: 'Invalid request to AI. Please rephrase your message.' });
    }
    if (err.code === 'ECONNABORTED') {
      return res.status(408).json({ success: false, message: 'AI response timed out. Please try again.' });
    }

    res.status(500).json({ success: false, message: 'AI service error. Please try again shortly.' });
  }
});

// @route   GET /api/chat/history
// @desc    Get all chats for current user
// @access  Private
router.get('/history', protect, async (req, res) => {
  try {
    const chats = await Chat.find({ user: req.user._id, isActive: true })
      .select('title createdAt updatedAt messages')
      .sort({ updatedAt: -1 })
      .limit(50);

    const chatList = chats.map((c) => ({
      id: c._id,
      title: c.title,
      messageCount: c.messages.length,
      lastMessage: c.messages[c.messages.length - 1]?.content?.substring(0, 80) || '',
      updatedAt: c.updatedAt,
      createdAt: c.createdAt,
    }));

    res.json({ success: true, chats: chatList });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load chat history.' });
  }
});

// @route   GET /api/chat/:chatId
// @desc    Get a specific chat with messages
// @access  Private
router.get('/:chatId', protect, async (req, res) => {
  try {
    const chat = await Chat.findOne({ _id: req.params.chatId, user: req.user._id });
    if (!chat) {
      return res.status(404).json({ success: false, message: 'Chat not found.' });
    }

    res.json({
      success: true,
      chat: {
        id: chat._id,
        title: chat.title,
        messages: chat.messages,
        createdAt: chat.createdAt,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load chat.' });
  }
});

// @route   DELETE /api/chat/:chatId
// @desc    Delete a chat
// @access  Private
router.delete('/:chatId', protect, async (req, res) => {
  try {
    const chat = await Chat.findOneAndUpdate(
      { _id: req.params.chatId, user: req.user._id },
      { isActive: false }
    );
    if (!chat) {
      return res.status(404).json({ success: false, message: 'Chat not found.' });
    }
    res.json({ success: true, message: 'Chat deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete chat.' });
  }
});

module.exports = router;
